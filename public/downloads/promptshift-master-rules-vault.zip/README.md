# PromptShift 50+ Master AI Coding Rules & Prompts Vault (v2.0 Production)
Copyright (c) 2026 PromptShift (https://promptshift.dev)

This production vault delivers 50+ battle-tested AI coding directives and modular rules ready for:
- Cursor IDE (.cursorrules & .cursor/rules/*.mdc)
- Anthropic Claude Code & Projects (CLAUDE.md & XML)
- GitHub Copilot (.github/copilot-instructions.md)
- Windsurf Cascade (.windsurfrules)
- Google Gemini CLI & Antigravity (GEMINI.md, AGENTS.md)

## Quick Start:
1. Copy the desired rule files into your repository root or .cursor/rules/ folder.
2. Synchronize your rules across all AI editors using the PromptShift CLI:
   ```bash
   npx promptshift --watch
   ```
