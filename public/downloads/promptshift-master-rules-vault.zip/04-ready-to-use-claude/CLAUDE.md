# PromptShift Universal CLAUDE.md Master Rules
- Stack: Next.js 15 App Router, TypeScript Strict, TailwindCSS v4.
- Workflow: Run 'npm test' and 'npm run build' before finishing turn.
- Security: Zero-retention RAM architecture, IDOR checks, fail-closed verification.
- Monetization: Polar.sh MoR integration for frictionless Apple Pay / Google Pay.
- CLI Sync: Use 'npx promptshift --watch' for bidirectional rules sync.
