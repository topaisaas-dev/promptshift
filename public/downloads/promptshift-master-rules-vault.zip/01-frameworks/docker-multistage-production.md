# Docker Production Hardening
- Use multi-stage builds to minimize image surface: builder stage -> production runner.
- Never run containers as root; define and use an unprivileged user (USER node / USER nonroot).
- Use minimal base images (distroless or alpine) and pin image digests.
- Never pass sensitive build secrets via ARG or ENV; use BuildKit '--mount=type=secret'.
