# Supabase & PostgreSQL Security Architecture
- Row Level Security (RLS) MUST be enabled on EVERY table without exception.
- Write explicit policies for SELECT, INSERT, UPDATE, and DELETE targeting (select auth.uid()).
- Never bypass RLS in client-side code; use the service_role key only in secure serverless backend functions.
- Add B-Tree database indexes on foreign keys, tenant IDs, and filtered columns in RLS policies.
