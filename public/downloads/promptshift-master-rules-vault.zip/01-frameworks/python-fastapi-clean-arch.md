# Python FastAPI & Pydantic v2 Production Directives
- Use strict Pydantic v2 schemas (ConfigDict(extra='forbid')) for all request payloads and response models.
- Implement dependency injection via FastAPI Depends() for database sessions, auth, and clients.
- Use asynchronous route handlers (async def) with non-blocking drivers (httpx, asyncpg).
- Handle exceptions with custom HTTPException classes and RFC 7807 Problem Details handlers.
- Enforce strict typing with mypy/ruff and type annotations on every function signature.
